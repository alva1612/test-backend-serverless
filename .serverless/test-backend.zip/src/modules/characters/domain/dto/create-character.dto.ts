export class CreateCharacterDto {}
