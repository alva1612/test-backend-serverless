export const DynamoModuleOptionsToken = Symbol('DynamoModuleOptions');
